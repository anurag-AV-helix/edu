import React from "react";

const NEW = () => {
  return <div>NEW</div>;
};

export default NEW;
