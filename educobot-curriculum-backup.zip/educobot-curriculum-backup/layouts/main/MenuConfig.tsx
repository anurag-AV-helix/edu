// routes
import { PATH_AUTH, PATH_DOCS, PATH_PAGE } from '../../routes/paths';
// components
import { PATH_AFTER_LOGIN } from '../../config';

import { Button } from '@mui/material';
// components
import Iconify from '../../components/Iconify';

// ----------------------------------------------------------------------

const ICON_SIZE = {
  width: 22,
  height: 22,
};

const menuConfig = [
  {
    title: 'Home',
    icon: <Iconify icon={'eva:home-fill'} {...ICON_SIZE} />,
    path: '/',
  },
  {
    title: 'Product',
    icon: <Iconify icon={'ic:round-grain'} {...ICON_SIZE} />,
    path: PATH_PAGE.product,
  },
  {
    title: 'Curriculum',
    path: PATH_PAGE.curriculum,
    icon: <Iconify icon={'eva:file-fill'} {...ICON_SIZE} />,
    // children: [
    //   {
    //     subheader: 'Other',
    //     items: [
    //       { title: 'About us', path: PATH_PAGE.about },
    //       { title: 'Contact us', path: PATH_PAGE.contact },
    //       { title: 'FAQs', path: PATH_PAGE.faqs },
    //       { title: 'Pricing', path: PATH_PAGE.pricing },
    //       { title: 'Payment', path: PATH_PAGE.payment },
    //       { title: 'Maintenance', path: PATH_PAGE.maintenance },
    //       { title: 'Coming Soon', path: PATH_PAGE.comingSoon },
    //     ],
    //   },
    //   {
    //     subheader: 'Authentication',
    //     items: [
    //       { title: 'Login', path: PATH_AUTH.loginUnprotected },
    //       { title: 'Register', path: PATH_AUTH.registerUnprotected },
    //       { title: 'Reset password', path: PATH_AUTH.resetPassword },
    //       { title: 'Verify code', path: PATH_AUTH.verify },
    //     ],
    //   },
    //   {
    //     subheader: 'Error',
    //     items: [
    //       { title: 'Page 404', path: PATH_PAGE.page404 },
    //       { title: 'Page 500', path: PATH_PAGE.page500 },
    //     ],
    //   },
    //   {
    //     subheader: 'Dashboard',
    //     items: [{ title: 'Dashboard', path: PATH_AFTER_LOGIN }],
    //   },
    // ],
  },
  {
    title: 'Library',
    icon: <Iconify icon={'eva:book-open-fill'} {...ICON_SIZE} />,
    path: PATH_PAGE.library,
  },
];

const phoneMenuConfig = [
  {
    title: 'Home',
    icon: <Iconify icon={'eva:home-fill'} {...ICON_SIZE} />,
    path: '/',
  },
  {
    title: 'Product',
    icon: <Iconify icon={'ic:round-grain'} {...ICON_SIZE} />,
    path: PATH_PAGE.product,
  },
  {
    title: 'Curriculum',
    path: PATH_PAGE.curriculum,
    icon: <Iconify icon={'eva:file-fill'} {...ICON_SIZE} />,
    // children: [
    //   {
    //     subheader: 'Other',
    //     items: [
    //       { title: 'About us', path: PATH_PAGE.about },
    //       { title: 'Contact us', path: PATH_PAGE.contact },
    //       { title: 'FAQs', path: PATH_PAGE.faqs },
    //       { title: 'Pricing', path: PATH_PAGE.pricing },
    //       { title: 'Payment', path: PATH_PAGE.payment },
    //       { title: 'Maintenance', path: PATH_PAGE.maintenance },
    //       { title: 'Coming Soon', path: PATH_PAGE.comingSoon },
    //     ],
    //   },
    //   {
    //     subheader: 'Authentication',
    //     items: [
    //       { title: 'Login', path: PATH_AUTH.loginUnprotected },
    //       { title: 'Register', path: PATH_AUTH.registerUnprotected },
    //       { title: 'Reset password', path: PATH_AUTH.resetPassword },
    //       { title: 'Verify code', path: PATH_AUTH.verify },
    //     ],
    //   },
    //   {
    //     subheader: 'Error',
    //     items: [
    //       { title: 'Page 404', path: PATH_PAGE.page404 },
    //       { title: 'Page 500', path: PATH_PAGE.page500 },
    //     ],
    //   },
    //   {
    //     subheader: 'Dashboard',
    //     items: [{ title: 'Dashboard', path: PATH_AFTER_LOGIN }],
    //   },
    // ],
  },
  {
    title: 'Library',
    icon: <Iconify icon={'eva:book-open-fill'} {...ICON_SIZE} />,
    path: PATH_PAGE.library,
  },
  {
    title: '',
    icon: <Button
      variant="outlined"
      target="_blank"
      rel="noopener"
      href="/auth/login"
      sx={{ marginRight: 1 }}
    >
      Login
    </Button>,
    path: PATH_PAGE.library,
  },
  {
    title: '',
    icon: <Button
      variant="contained"
      target="_blank"
      rel="noopener"
      href="/auth/registeration"
    >
      Sign Up
    </Button>,
    path: PATH_PAGE.library,
  },
];

export default menuConfig;
export { phoneMenuConfig };