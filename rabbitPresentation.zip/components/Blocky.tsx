import React, { useEffect, useState } from "react";
import { BlocklyWorkspace } from "react-blockly";
import Blockly from "blockly";
import 'blockly/python';
import 'blockly/javascript';
import "./toolbox"
import zolo from "../theme/zolo"


export default function Blocky(props) {

    const block = require('../public/block/' + props.slug)

    const [setXml] = useState(null);
    const initialXml = '<xml xmlns="http://www.w3.org/1999/xhtml"></xml>';
    const toolboxCategories = {
        kind: "categoryToolbox",
        collapsed: false,
        contents: [
            {
                kind: block.blocks.kind,
                name: block.blocks.name,
                colour: block.blocks.colour,
                contents: block.blocks.contents
            },
            {
                kind: "category",
                name: "Logic",
                colour: "#006ad6",
                contents: [
                    {
                        kind: "block",
                        type: "controls_if"
                    },
                    {
                        "kind": "block",
                        "type": "logic_negate"
                    },
                ],
            },
            {
                kind: "category",
                name: "Boolean",
                colour: "#74caff",
                contents: [
                    {
                        kind: "block",
                        type: "logic_compare",
                    },
                    {
                        "kind": "block",
                        "type": "logic_operation"
                    },
                    {
                        "kind": "block",
                        "type": "logic_boolean"
                    },

                ]
            },
            {
                kind: "category",
                name: "Loop",
                colour: "#00ef00",
                contents: [
                    {
                        kind: "block",
                        type: "controls_whileUntil"
                    },
                    {
                        kind: "block",
                        type: "controls_for"
                    },
                    {
                        kind: "block",
                        type: "controls_forEach"
                    },
                    {
                        kind: "block",
                        type: "controls_repeat"
                    },
                    {
                        kind: "block",
                        type: "controls_flow_statements"
                    },
                ]
            },
            {
                kind: "category",
                name: "Math",
                colour: "#5CA65C",
                contents: [
                    {
                        kind: "block",
                        type: "math_round",
                    },
                    {
                        kind: "block",
                        type: "math_number",
                    },
                    {
                        "kind": "block",
                        "type": "math_arithmetic"
                    },
                    {
                        "kind": "block",
                        "type": "math_single",
                        //"disabled": "true"
                    }
                ],
            },

        ],
    };

    function workspaceDidChange(workspace: any) {
        const Pycode: string = (Blockly as any).Python.workspaceToCode(workspace);
        const Jscode: string = (Blockly as any).JavaScript.workspaceToCode(workspace);
        props.setPythonCode(Pycode)
        props.setJavaScript(Jscode)
    }

    return (
        <BlocklyWorkspace
            toolboxConfiguration={toolboxCategories}
            initialXml={initialXml}
            className="fill-height"
            workspaceConfiguration={{
                horizontalLayout: true,
                grid: {
                    spacing: 20,
                    length: 3,
                    colour: "#ccc",
                    snap: true,
                },
                zoom: {
                    controls: true,
                    wheel: true,
                    startScale: 1.0,
                    maxScale: 3,
                    minScale: 0.3,
                    scaleSpeed: 1.2,
                    pinch: true
                },
                move: {
                    scrollbars: {
                        horizontal: true,
                        vertical: true
                    },
                    drag: true,
                    wheel: false
                },
                renderer: "zelos",
                theme: zolo
            }}
            onWorkspaceChange={workspaceDidChange}
            onXmlChange={setXml}
        />

    );
}
