import { useEffect, useState } from "react";
import type { NextPage } from "next";
import Image from "next/image";
import dynamic from "next/dynamic";
import { GetStaticPaths, GetStaticProps } from "next/types";
import { existsSync, writeFileSync } from "fs";
import Canvas from "../../../components/Canvas";
import styles from "../../../styles/Problems.module.css";
import TestDialog from "../../../MyComponents/DialogBoxes/TutorialDialog";
const Blocky = dynamic(import("../../../components/Blocky"), { ssr: false });
const ShepherdTour = dynamic(import("../../../components/shepherdTour"), {
  ssr: false,
});
import * as XLSX from "xlsx";
import path from "path";
import Router from "next/router";

const language = {
  English: 1,
  Hindi: 2,
  Marathi: 3,
  Spanish: 4,
  Arabic: 5,
  Swaheli: 6,
};

export const getStaticPaths: GetStaticPaths<{ slug: string }> = async () => {
  const response = await fetch("http://localhost:3000/title.json");
  const json = await response.json();
  const paths = json.title.map((t) => ({ params: t.params }));

  return {
    paths,
    fallback: false,
  };
};

export const getStaticProps: GetStaticProps = async (context) => {
  const readedData = XLSX.readFile("public/BunnyLanguageTemplate.xlsx", {
    type: "binary",
  });

  const wsname = readedData.SheetNames[0];
  const ws = readedData.Sheets[wsname];

  /* Convert array to json*/
  const dataParse: any[] = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const res = await fetch(
    `http://localhost:3000/files/${context.params.slug}.js`
  );
  //const res = await fetch(`http://localhost:3000/files/bunny.js`)
  const anim = await res.text();

  const res1 = await fetch(
    `http://localhost:3000/blocks/${context.params.slug}_Blocks.js`
  );
  //const res1 = await fetch(`http://localhost:3000/blocks/bunny_Blocks.js`)
  const block = await res1.text();

  const blockPath = path.join(process.cwd(), "public", "block");
  const animPath = path.join(process.cwd(), "public", "anim");

  const blockFileName = path.join(blockPath, `${context.params.slug}.js`);
  const animFileName = path.join(animPath, `${context.params.slug}.js`);

  if (!existsSync(blockFileName)) {
    writeFileSync(blockFileName, block);
  }

  if (!existsSync(animFileName)) {
    writeFileSync(animFileName, anim);
  }

  return {
    props: { dataParse, slug: context.params.slug },
  };
};

const Home: NextPage<any> = (props) => {
  const { dataParse, slug } = props;
  const tut: any[] = dataParse.map((data) => data[language.English]);
  tut.shift();
  const [muteState, setMute] = useState(false);
  const [command, setcommand] = useState("");
  const [reset, setReset] = useState(false);
  const [javascriptCode, setJavascriptCode] = useState("");
  const [PythonCode, setPythonCode] = useState("");

  let startAnimating: () => void;

  const handleClick = async () => {
    // let slugModule = dynamic(async () => await import(`../../../public/anim/${slug}.js`),
    //     { ssr: false }
    // )

    try {
      window[`${slug}`] = require(`../../../public/anim/${slug}.js`);
      startAnimating = window[`${slug}`]?.reset_output;
      startAnimating();
      try {
        eval(`(async function(){ ${javascriptCode} })();`);
      } catch (e) {
        Router.push("/_error");
      }
    } catch (e) {
      Router.push("/_error");
    }
  };

  useEffect(() => {
    if (window[`${slug}`] === "bunny") {
      const interval = setInterval(() => {
        window[`${slug}`] = require(`../../../public/anim/${slug}.js`);
        let completed = window[`${slug}`].completedFlag;
        console.log(completed());
        if (completed()) {
          document.getElementById("openTest").click();
          clearInterval(interval);
        }
      }, 2000);

      return () => clearInterval(interval);
    }
  }, []);

  return (
    <>
      <div
        style={{
          display: "grid",
          height: "100%",
          gridTemplateColumns: "repeat(2, 1fr)",
        }}
      >
        <Blocky
          slug={slug}
          setJavaScript={setJavascriptCode}
          setPythonCode={setPythonCode}
        />
        <div
          id="circle"
          className={styles.canvas}
          style={{ padding: "0 1rem" }}
        >
          <div className={""}>
            <button
              className={`${styles.normal_button} `}
              data-position="bottom"
              data-tooltip="Run Code"
              id="runbtn"
              onClick={handleClick}
            >
              <Image
                src="/assets/run_button_icon_landscape.png"
                width="30"
                height="30"
              />
            </button>
            <button
              className={`${styles.normal_button} `}
              data-position="bottom"
              data-tooltip="Reset Output"
              onClick={() => setReset(!reset)}
            >
              <img src="/assets/reset_button_icon.png" width="30" height="30" />
            </button>
            <button
              className={`${styles.normal_button}  ${styles.sound}`}
              data-position="bottom"
              data-tooltip="Open Keyboard"
              id="soundBtn"
              onClick={() => setMute(!muteState)}
            >
              <img
                src={muteState ? "/assets/mute.png" : "/assets/unmute.png"}
                width="30"
                height="30"
              />
            </button>
          </div>
          {
            <Canvas
              command={command}
              id="sprite"
              className={""}
              handleReset={setReset}
              reset={reset}
              setCommand={setcommand}
              slug={slug}
              //file={canvasFile}
            />
          }
          <div
            id="pycode"
            className={styles.output}
            style={{ minHeight: "9vh" }}
          >
            <b style={{ color: "#fff", display: "contents" }}>import {slug} </b>{" "}
            <br />
            {PythonCode}
          </div>
          <TestDialog
            testDialogInfo={{
              dialogStatus: "test",
              questionArray: [
                {
                  id: 1,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 1.True",
                  answer: 0,
                },
                {
                  id: 2,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 2.False",
                  answer: 1,
                },
                {
                  id: 3,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 3.True",
                  answer: 0,
                },
                {
                  id: 4,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 2.False",
                  answer: 1,
                },
                {
                  id: 5,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 3.True",
                  answer: 0,
                },
              ],
            }}
          />
        </div>
      </div>
      <label id="hand" htmlFor="test">
        <img src="/assets/hand_upward.png" width="50px" height="60px" />
      </label>
      <ShepherdTour tut={tut} />
    </>
  );
};
export default Home;
{
  /* <div className={styles.neumorphic_button_container}>

                        <button className={`${styles.neumorphic_button}  ${styles.tooltip}`}
                            data-position="bottom" data-tooltip="Run Code"
                            id='runbtn'
                            onClick={handleClick}
                        >
                            <span className={`${styles.tooltiptext}`}>Run Scritp</span>
                            <Image src="/assets/run_button_icon_landscape.png"
                                width="30" height="30"
                            />
                        </button>
                        <button className={`${styles.neumorphic_button}  ${styles.tooltip}`}
                            data-position="bottom" data-tooltip="Reset Output"
                            onClick={() => setReset(!reset)}
                        >
                            <span className={`${styles.tooltiptext}`}>Run Scritp</span>
                            <img src="/assets/reset_button_icon.png"
                                width="30" height="30"
                            />
                        </button>
                        <button className={`${styles.neumorphic_button}  ${styles.tooltip}`}
                            data-position="bottom" data-tooltip="Open Keyboard"
                            id="soundBtn"
                            onClick={() => setMute(!muteState)}
                        >
                            <span className={`${styles.tooltiptext}`}>{muteState ? "Mute" : "Unmute"}</span>
                            <img src={muteState ? "/assets/mute.png" : "/assets/unmute.png"}
                                width="30" height="30"
                            />
                        </button>
</div> */
}
