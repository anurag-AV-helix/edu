import React, { useEffect } from 'react'
export default function game({ slug }) {
    useEffect(() => {
        window[`${slug}`] = require(`../../../public/game/${slug}/main`)
    }, [])

    return (
        <div id='sprite-container' />
    )
}
