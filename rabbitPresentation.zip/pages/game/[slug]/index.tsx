import React, { useEffect, useState } from "react";
import type { NextPage } from "next";
import Image from "next/image";
import dynamic from "next/dynamic";
import styles from "../../../styles/Problems.module.css";
import Game from "./game";
const Blocky = dynamic(import("../../../components/Blocky"), { ssr: false });
import TestDialog from "../../../MyComponents/DialogBoxes/TutorialDialog";
//const Tour = dynamic(import('../components/tour'), { ssr: false })
const ShepherdTour = dynamic(import("../../../components/shepherdTour"), {
  ssr: false,
});
export default function AnimationFarm() {
  const slug = "farm";

  const [muteState, setMute] = useState(false);
  const [reset, setReset] = useState(false);
  const [javascriptCode, setJavascriptCode] = useState("");
  const [PythonCode, setPythonCode] = useState("");

  const handleClick = async () => {
    try {
      eval(`(async function(){ ${javascriptCode} })();`);
    } catch (e) {
      alert(e);
    }
  };
  const reSet = () => {
    window[`${slug}`].reset_output();
  };

  useEffect(() => {
    const interval = setInterval(() => {
      let completed = window[`${slug}`].completedFlag;
      console.log(completed());
      if (completed()) {
        document.getElementById("openTest").click();

        clearInterval(interval);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);
  return (
    <>
      <div
        style={{
          display: "grid",
          height: "100%",
          gridTemplateColumns: "repeat(2, 1fr)",
        }}
      >
        <Blocky
          slug={slug}
          setJavaScript={setJavascriptCode}
          setPythonCode={setPythonCode}
        />
        <div className={styles.canvas} style={{ padding: "0 1rem" }}>
          <div className={""}>
            <button
              className={`${styles.normal_button} `}
              data-position="bottom"
              data-tooltip="Run Code"
              id="runbtn"
              onClick={handleClick}
            >
              <Image
                src="/assets/run_button_icon_landscape.png"
                width="30"
                height="30"
              />
            </button>
            <button
              className={`${styles.normal_button} `}
              data-position="bottom"
              data-tooltip="Reset Output"
              onClick={reSet}
            >
              <img src="/assets/reset_button_icon.png" width="30" height="30" />
            </button>
            <button
              className={`${styles.normal_button}  ${styles.sound}`}
              data-position="bottom"
              data-tooltip="Open Keyboard"
              id="soundBtn"
              onClick={() => setMute(!muteState)}
            >
              <img
                src={muteState ? "/assets/mute.png" : "/assets/unmute.png"}
                width="30"
                height="30"
              />
            </button>
          </div>
          <Game slug={slug} />

          <div
            id="pycode"
            className={styles.output}
            style={{ minHeight: "9vh" }}
          >
            <b style={{ color: "#fff", display: "contents" }}>import farm</b>{" "}
            <br />
            {PythonCode}
          </div>
          <TestDialog
            testDialogInfo={{
              dialogStatus: "test",
              questionArray: [
                {
                  id: 1,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 1.True",
                  answer: 0,
                },
                {
                  id: 2,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 2.False",
                  answer: 1,
                },
                {
                  id: 3,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 3.True",
                  answer: 0,
                },
                {
                  id: 4,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 2.False",
                  answer: 1,
                },
                {
                  id: 5,
                  question:
                    "Quisque vulputate nec arcu id sodales. Aenean ipsum nisi, congue luctus pretium id, dignissim vel nisl. 3.True",
                  answer: 0,
                },
              ],
            }}
          />
        </div>
      </div>
      {/* <label id="hand" htmlFor="test">
                <img src="/assets/hand_upward.png" width="50px" height="60px" />
            </label>
            <ShepherdTour tut={tut} /> */}
    </>
  );
}
