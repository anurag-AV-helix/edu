import React, { useEffect, useState } from 'react'
import type { NextPage } from 'next'
import Image from 'next/image'
import dynamic from 'next/dynamic';
import styles from '../styles/Problems.module.css'
//const Tour = dynamic(import('../components/tour'), { ssr: false })
import { runIt } from "../skulpt/worker";
export default function farm() {
    const k = `import turtle
t = turtle.Turtle()
for c in ['red', 'green', 'yellow', 'blue']:
    t.color(c)
    t.forward(75)
    t.left(90)`
    const clear = `import turtle
t = turtle.Turtle()
t.clear()`
    const [muteState, setMute] = useState(false);
    const [reset, setReset] = useState(false)
    const PythonCode = k;


    const handleClick = async () => {
        runIt(PythonCode)
    }
    const clearScreen = () => {
        runIt(clear)
    }
    return (
        <>
            <div style={{ display: "grid", height: "100%", gridTemplateColumns: "repeat(2, 1fr)" }}>
                <div className={styles.canvas} style={{ padding: '0 1rem' }}>
                    <div className={''}>
                        <button className={`${styles.normal_button} `}
                            data-position="bottom" data-tooltip="Run Code"
                            id='runbtn'
                            onClick={handleClick}
                        >
                            <Image src="/assets/run_button_icon_landscape.png"
                                width="30" height="30"
                            />
                        </button>
                        <button className={`${styles.normal_button} `}
                            data-position="bottom" data-tooltip="Reset Output"
                            onClick={clearScreen}
                        >
                            <img src="/assets/reset_button_icon.png"
                                width="30" height="30"
                            />
                        </button>
                        <button className={`${styles.normal_button}  ${styles.sound}`}
                            data-position="bottom" data-tooltip="Open Keyboard"
                            id="soundBtn"
                            onClick={() => setMute(!muteState)}
                        >
                            <img src={muteState ? "/assets/mute.png" : "/assets/unmute.png"}
                                width="30" height="30"
                            />
                        </button>
                    </div>
                    <div id='circle' />
                    <div id="pycode" className={styles.output} style={{ minHeight: '9vh' }}>
                        {PythonCode}
                    </div>
                    <div id="output" />
                </div>
            </div>
            {/* <label id="hand" htmlFor="test">
                <img src="/assets/hand_upward.png" width="50px" height="60px" />
            </label>
            <ShepherdTour tut={tut} /> */}
        </>
    )
}
