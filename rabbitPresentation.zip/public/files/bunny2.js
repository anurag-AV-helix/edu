let bunny = {
    // start_x: 132,
    // start_y: 405,
    // x: 33,
    // y: 305,
    // width: 81,
    // height: 112,
    // frameX: 0,
    // frameY: 0,
    // speed: 9,
    // moving: false,
    // display_factor: 1.0,
    // scale_factor_y: 0.3,
    // visible: true,
    x: -100, y: 1270, width: 100,
    height: 119, frameX: 0, frameY: 0, speed: 90,
    moving: false, display_factor: 6,
};

let carrot = {
    x: 3750, y: 1720, width: 250, height: 250,
    visible: true,
};

const house = {
    x: 0, y: 800, width: 1000, height: 1800,
};
const home = {
    x: 0,
    y: 800,
    width: 1000,
    height: 1800,
}
const bunnySprite = new Image();
bunnySprite.src = "/img/Bunny_2_lowres.png";
const houseSprite = new Image();
houseSprite.src = "/img/forest_2_for_bunny.png";
const carrotSprite = new Image();
carrotSprite.src = "/img/carrot.png";

const drawBunny = (img, sX, sY, sW, sH, dX, dY, dW, dH, ctx) => {
    ctx.drawImage(img, sX, sY, sW, sH, dX, dY, dW, dH);
};

const drawCarrot = (img, sX, sY, sW, sH, ctx) => {
    ctx.drawImage(img, sX, sY, sW, sH);
};

const drawHouse = (img, sX, sY, sW, sH, ctx) => {
    ctx.drawImage(img, sX, sY, sW, sH);
};
function bunnyFrame() {
    if (bunny.frameX < 7 && bunny.moving)
        bunny.frameX++;
    else bunny.frameX = 0;
}
var fps, fpsInterval, startTime, now, then, elapsed;

const startAnimating = (fps, ctx, canvas) => {
    fpsInterval = 1000 / fps;
    then = performance.now();
    startTime = then;
    animate(ctx, canvas);
};

const animate = (ctx, canvas) => {
    requestAnimationFrame(() => animate(ctx, canvas));
    now = Date.now();
    elapsed = now - then;
    if (elapsed > fpsInterval) {
        then = now - (elapsed % fpsInterval);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(houseSprite, 0, 0, canvas.width, canvas.height);
        //drawHouse(houseSprite, house.x, house.y, house.width, house.height, ctx);
        if (carrot.visible)
            drawCarrot(carrotSprite, carrot.x, carrot.y, carrot.width, carrot.height, ctx);
        if (bunny.visible)
            drawBunny(
                bunnySprite,
                bunny.width * bunny.frameX,
                bunny.height * bunny.frameY,
                bunny.width,
                bunny.height,
                bunny.x,
                bunny.y,
                bunny.width * bunny.display_factor,
                bunny.height * bunny.display_factor,
                ctx
            );

        bunnyFrame();
        requestAnimationFrame(() => animate(ctx, canvas));
    }
};

var eatCarrot = async () => {
    return new Promise((resolve) => {
        if (
            bunny.x > carrot.x + carrot.width ||
            bunny.x + bunny.width < carrot.x ||
            bunny.y > carrot.y + carrot.height ||
            bunny.y + bunny.height < carrot.y
        ) {
            return resolve();
        } else {
            carrot.visible = false;
            return resolve();
        }
    });
};
let anim
function left(move_distance,) {
    anim = requestAnimationFrame(function () {
        left(move_distance)
    });

    if (Date.now() - then > 70) {
        //left_running = true;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(houseSprite, 0, 0, canvas.width, canvas.height);
        drawSprite(bunnySprite,
            bunny.width * bunny.frameX,
            bunny.height * bunny.frameY,
            bunny.width,
            bunny.height,
            bunny.x,
            bunny.y,
            bunny.width * bunny.display_factor,
            bunny.height * bunny.display_factor
        );
        if (carrot.visible)
            ctx.drawImage(carrot, carrot.x, carrot.y, carrot.width, carrot.height);
        ctr += 1;
        if (ctr > move_distance || bunny.x < -10) {
            ctr = 0; cancelAnimationFrame(anim); bunny.moving = false;
            // left_running = false;
            // collision_check();
            // evaluate_task();
            //        if (player.x < -15) M.toast({ html: "End of screen!" }); return; 
        }
        bunny.x -= bunny.speed;
        bunny.frameY = 1;
        bunny.moving = true;
        bunnyFrame();
        then = Date.now();
    }

}
var right = async (steps) => {
    //console.log(dog, bone, house, grass1, grass2, grass3)
    let interval = 0;
    let requiredRuns = 0;
    let speed = 0;

    interval = 116;
    requiredRuns = parseInt(steps) * 2 - 7;
    speed = 8;

    return new Promise((resolove) => {
        let timesRun = 0;
        const intervalDur = setInterval(() => {
            timesRun += 1;

            if (timesRun === requiredRuns) {
                bunny.moving = false;
                clearInterval(intervalDur);
                return resolove();
            }

            bunny.x += bunny.speed;
            bunny.frameY = 0;
        }, interval);
        bunny.frameY = 1;
        bunny.moving = true;
        bunny.speed = speed;
    });
};



var sleep = async (milliseconds) => {
    return new Promise((resolve) => {
        setTimeout(function () {
            resolve();
        }, milliseconds);
    });
};

const resetBunny = (ctx, canvas) => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    bunny = {
        start_x: 257,
        start_y: 405,
        x: 33,
        y: 305,
        width: 78,
        height: 104,
        frameX: 0,
        frameY: 0,
        speed: 9,
        moving: false,
        display_factor: 1.0,
        scale_factor_y: 0.3,
        visible: true,
    },
        carrot = {
            x: 676,
            y: 375,
            width: 32,
            height: 26,
            visible: true,
        };

    fps = fpsInterval = startTime = now = then = elapsed = undefined
    bunnyFrame()
    startAnimating(10, ctx, canvas)
}
export { eatCarrot, resetBunny, startAnimating, right, sleep }
