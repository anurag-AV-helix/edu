def moveUp():
    print("move('up')")
def moveDown():
    print("move('down')")
def moveRight():
    print("move()")
def eatBone():
    print("eatBone()")
def turn():
    print("turn()")
def sleep(arg):
    print(f"sleep({arg})")
def enterHouse():
    print("enterHouse()")