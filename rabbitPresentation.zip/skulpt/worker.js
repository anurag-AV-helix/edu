try {
    import("./skulpt.min.js");
    import("./skulpt-stdlib.js");
} catch (exception) {
    console.log(exception);
}

var externalLibs = {
    "./numpy/__init__.js": "https://cdn.jsdelivr.net/gh/ebertmi/skulpt_numpy@master/numpy/__init__.js"
};

function builtinRead(file) {
    if (externalLibs[file] !== undefined) {
        return Sk.misceval.promiseToSuspension(
            fetch(externalLibs[file]).then(
                function (resp) {
                    console.log(resp)
                    return resp.text();
                }
            ));
    }

    if (Sk.builtinFiles === undefined || Sk.builtinFiles.files[file] === undefined) {
        throw "File not found: '" + file + "'";
    }

    return Sk.builtinFiles.files[file];
}

function outf(text) {
    const mypre = document.getElementById("output");
    mypre.innerHTML = mypre.innerHTML + text;
}
function runIt(pythonCode) {
    Sk.pre = "output";
    Sk.configure({ output: outf, read: builtinRead, __future__: Sk.python3, });
    (Sk.TurtleGraphics || (Sk.TurtleGraphics = {})).target = 'circle';
    var myPromise = Sk.misceval.asyncToPromise(function () {
        return Sk.importMainWithBody("<stdin>", false, pythonCode, true);
    });
    myPromise.then(
        function (mod) {
            //console.log(Sk.ffi.remapToJs(Sk.globals["phase"]));
        },
        function (err) {
            console.log(err.toString());
        }
    );
}

function handleMessage(event) {
    const action = event.data.action,
        messageId = event.data.messageId,
        params = event.data.params,
        data = runIt(params);
    return {
        data: data,
        messageId: messageId
    };
}

export { handleMessage, externalLibs, runIt, outf }
