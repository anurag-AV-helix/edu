let isStageCompleted = false;
let isModalClosed = false;
var tour_over = false;
var audio = new Audio();
let kill_audio = () => {
    if (!audio.paused) audio.pause();
};
let language = {
    language_packs_folder: "languages",
    language: "english",
    audio_folder: "audio",
    image_folder: "images",
    guide_folder: "guide",
};
//const code = `print("Hello World")`.split("");
//const user_code = "".split("")
let pred_guide = [];

function image_scaler(file) {
    let path = `./` + language.image_folder + `/`;
    return `<img src = "` + path + file + `" class="responsive-img">`;
}

function play_audio_tutorial(file) {
    let path = `./` + language.audio_folder + `/`;
    if (!audio.paused) audio.pause();
    audio = new Audio(path + file);
    audio.play();
}

function chk() {
    if (user_code.join("") === `name`) return "step 1 tutorial";
    else return false;
}

function make_pred_guide(id, file, code, audio) {
    pred_guide.push({
        html: `<div id="` +
            id +
            `" class="modal modal-fixed-footer transparent">
        <div id="` +
            id +
            `_content" class="modal-content center-align">` +
            image_scaler(file) +
            `</div>
        <div class="modal-footer transparent"><a href="#!" class="modal-close waves-effect waves-gray btn-flat white-text black" onclick="document.getElementById('modal').close(); isModalClosed=true;">Understood</a></div></div>`,
        shown: false,
        id: id,
        file: file,
        code: code,
        audio: audio,
    });
}
make_pred_guide("tip0", "tip0.png", ``, ``);
make_pred_guide("tip1", "tip1.png", `print`, `line52.mp3`);
make_pred_guide(
    "tip2",
    "tip2_HelloWorld.png",
    `print("Hello World")`,
    `line0.mp3`
);

pred_guide.forEach((i) => {
    //document.querySelector('body').append(i.html);
    //document.getElementById('modal').close();
    document.querySelector("dialog");
});

function helpCode(user_code) {
    pred_guide.forEach((i) => {
        i.shown = false;
    });
    tutorial_guide_updater(user_code);
}

function tutorial_guide_updater(user_code) {
    pred_guide.forEach((i, index) => {
        isModalClosed = false;
        if (i.shown == false && i.code === user_code.join("")) {
            document.getElementById("modal").innerHTML = i.html;
            document.getElementById("modal").show();
            i.shown = true;
            if (!(i.audio === undefined || i.audio == "")) {
                play_audio_tutorial(i.audio);
            }
            if (index === pred_guide.length - 1) {
                isStageCompleted = true;
            }
        }
    });
}

function completedFlag() {
    // return document.getElementById("modal").isShown();
    if (isStageCompleted) return isStageCompleted;
    return false;
}

export { tutorial_guide_updater, helpCode, completedFlag };